/*
  Warnings:

  - Added the required column `rh` to the `Doacao` table without a default value. This is not possible if the table is not empty.
  - Added the required column `tipoSanguineo` to the `Doacao` table without a default value. This is not possible if the table is not empty.

*/
-- AlterTable
ALTER TABLE "Doacao" ADD COLUMN     "rh" "RH" NOT NULL,
ADD COLUMN     "tipoSanguineo" "TipoSanguineo" NOT NULL;
