"use client";
import { CalendarDate, parseAbsoluteToLocal, parseDate } from "@internationalized/date";
import { Button } from "@nextui-org/button";
import { Card, CardBody, CardHeader } from "@nextui-org/card";
import { DateInput, TimeInput } from "@nextui-org/date-input";
import { Input } from "@nextui-org/input";
import { Radio, RadioGroup } from "@nextui-org/radio";
import { Select, SelectItem } from "@nextui-org/select";
import { RH, TipoSanguineo } from "@prisma/client";
import Link from "next/link";
import { FormEvent, useEffect, useState } from 'react';
import { useSearchParams } from 'next/navigation';

export default function Doacao() {
    const seachParams =  useSearchParams();
    const [id, setId] = useState(''); // Estado para armazenar o nome
    const [volume, setVolume] = useState(''); // Estado para armazenar o CPF
    const [data, setData] = useState(parseDate(new Date().toISOString().split('T')[0]).toString()); // Estado para armazenar o contato
    const [hora, setHora] = useState(parseAbsoluteToLocal(new Date().toISOString()).toString());
    const [tipoSanguineo, setTipoSanguineo] = useState(''); // Estado para armazenar o tipo sanguíneo
    const [rh, setRh] = useState(''); // Estado para armazenar o RH
    const [isLoading, setIsLoading] = useState(false); // Estado para rastrear o status de carregamento

    async function handleSubmit(event: FormEvent) {
        event.preventDefault();
        setIsLoading(true); // Ativa o estado de carregamento antes da solicitação

        const body = {
            id,
            volume,
            data,
            hora,
            tipoSanguineo,
            rh
        };

        try {
            const response = await fetch("/api/doacao", {
                method: "POST",
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(body)
            });

            if (!response.ok) {
                throw new Error(`HTTP error status: ${response.status}`);
            }

            const result = await response.json();
            console.log(result); // Exibe a resposta do servidor no console
        } catch (error) {
            console.error('Error:', error);
        } finally {
            setIsLoading(false); // Desativa o estado de carregamento após a conclusão da solicitação
        }
    }


    useEffect(()=>{
        setId(seachParams.get("codigo") ?? "");
        setRh(seachParams.get("rh") ?? "")
        setTipoSanguineo(seachParams.get("tipoSanguineo") ?? "");
        console.log(tipoSanguineo)
      },[])

    return (
        <main className="h-screen flex justify-center items-center">
            <div className="w-max space-y-3">
                <Card className="w-[350px]">
                    <CardHeader>
                        <h1 className="w-full text-xl font-bold text-center">
                            Doar
                        </h1>
                    </CardHeader>
                    <CardBody>
                        <form onSubmit={handleSubmit} className="grid gap-3">
                            <Input label="id" value={id} placeholder="Digite..." onChange={(e) => setId(e.target.value)} isRequired />
                            <Input label="volume" placeholder="Digite..." onChange={(e) => setVolume(e.target.value)} isRequired />
                            <DateInput
                                label={"Data"}
                                defaultValue={parseDate(new Date().toISOString().split('T')[0])}
                                placeholderValue={new CalendarDate(2024, 1, 1)}
                                onChange={(e) => setData(e.toDate("BRT").toISOString())}
                            />
                            <TimeInput
                                defaultValue={parseAbsoluteToLocal(new Date().toISOString())}
                                label="Hora"
                                onChange={(e) => setHora(e.toString())}
                                />
                            <Select selectedKeys={tipoSanguineo} defaultSelectedKeys={[tipoSanguineo]} label="Tipo Sanguineo" placeholder="Selecione..." onChange={(e) => setTipoSanguineo(e.target.value)} isRequired>
                                {Object.values(TipoSanguineo).map((tipo) => (
                                    <SelectItem key={tipo} value={tipo}>
                                        {tipo}
                                    </SelectItem>
                                ))}
                            </Select>
                            <RadioGroup
                                isRequired
                                label="RH"
                                orientation="horizontal"
                                value={rh}
                                onChange={(e) => setRh(e.target.value)}
                            >
                                {Object.values(RH).map((tipo) => (
                                    <Radio size="sm" key={tipo} value={tipo}>{tipo}</Radio>
                                ))}
                            </RadioGroup>
                            <Button isLoading={isLoading} type="submit" className="w-max justify-self-center mt-3">Doar</Button>
                        </form>
                    </CardBody>
                </Card>
                <Button>
                    <Link href="/buscaDoador">
                        Buscar
                    </Link>
                </Button>
            </div>
        </main>
    );
}
