"use client";
import React, { useCallback, useState, useEffect } from "react";
import { Button, ButtonGroup } from "@nextui-org/button";
import { Spinner } from "@nextui-org/spinner";
import { Pagination } from "@nextui-org/pagination";
import {
  Table,
  TableBody,
  TableCell,
  TableColumn,
  TableHeader,
  TableRow,
} from "@nextui-org/table";
import { Doador } from "@prisma/client";
import Link from "next/link";
import { useRouter } from "next/navigation";
import {
  Modal,
  ModalBody,
  ModalContent,
  ModalFooter,
  ModalHeader,
  useDisclosure,
} from "@nextui-org/modal";

const columns = [
  {
    key: "codigo",
    label: "Codigo",
  },
  {
    key: "nome",
    label: "Nome",
  },
  {
    key: "tipoSanguineo",
    label: "Tipo Sanguineo",
  },
  {
    key: "rh",
    label: "RH",
  },
  {
    key: "act",
    label: "Ações",
  },
];

export default function ResultDoador() {
  
  const { isOpen, onOpen, onOpenChange } = useDisclosure();
  const [codigo, setCodigo] = useState(0);
  const [page, setPage] = useState(1);
  const [pages, setPages] = useState(0);
  const [doadores, setDoadores] = useState<Doador[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const rowsPerPage = 10;
  const router = useRouter();

  const fetchDoadores = async () => {
    setIsLoading(true);
    try {
      const res = await fetch(`/api/doador?${location.href.split("?")[1]}`);
      const data = await res.json();
      setDoadores(data.doadores);
      setPages(Math.ceil(data.doadores.length / rowsPerPage));
    } catch (error) {
      console.error("Error fetching doadores:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const handlerDelete = async (codigo: number) => {
    try {
      await fetch(`/api/doador?codigo=${codigo}`, {
        method: "DELETE",
      });
      await fetchDoadores(); // Refresh the data after successful deletion

      // Verifica se a página atual está vazia após a exclusão
      if (items.length === 0 && page > 1) {
        setPage(page - 1); // Volta para a página anterior
      }
    } catch (error) {
      console.error("Error deleting doador:", error);
      alert("An error occurred while deleting the doador.");
    }
  };

  useEffect(() => {
    fetchDoadores();
  }, []);

  const items = React.useMemo(() => {
    const start = (page - 1) * rowsPerPage;
    const end = start + rowsPerPage;

    return doadores.slice(start, end);
  }, [page, doadores, pages]);

  const renderCell = useCallback((user: any, columnKey: any) => {
    const cellValue = user[columnKey];

    switch (columnKey) {
      case "act":
        return (
          <ButtonGroup>
            <Button color="primary">
              <Link href={`/mudaDoador?codigo=${user["codigo"]}`}>Alterar</Link>
            </Button>

            <Button color="success">
              Doar
            </Button>


            <Button
              onPress={onOpen}
              color="danger"
              onClick={() => setCodigo(user["codigo"])}
            >
              Deletar
            </Button>
          </ButtonGroup>
        );
      default:
        return cellValue;
    }
  }, []);

  return (
    <div className="h-screen flex flex-col justify-center items-center">
      <div className="space-y-3">
        <Table aria-label="Example table with dynamic content" className="w-[800px] h-[500px]">
          <TableHeader columns={columns}>
            {(column) => (
              <TableColumn key={column.key}>{column.label}</TableColumn>
            )}
          </TableHeader>
          <TableBody
            items={items}
            isLoading={isLoading}
            loadingContent={<Spinner />}
            emptyContent="Não houve Doadores"
          >
            {(item) => (
              <TableRow key={item.codigo}>
                {(columnKey) => (
                  <TableCell>{renderCell(item, columnKey)}</TableCell>
                )}
              </TableRow>
            )}
          </TableBody>
        </Table>
        <div>
          <ButtonGroup>
            <Button>
              <Link href="/buscaDoador">Voltar</Link>
            </Button>
            <Button>
              <Link href="/">Registrar</Link>
            </Button>
          </ButtonGroup>

          {pages > 1 && <Pagination
            page={page}
            total={pages}
            initialPage={1}
            onChange={(page) => setPage(page)}
          />}
        </div>

      </div>
      <Modal isOpen={isOpen} onOpenChange={onOpenChange}>
        <ModalContent>
          {(onClose) => (
            <>
              <ModalHeader>
                <h1 className="text-red-500">DELETAR DOADOR</h1>
              </ModalHeader>
              <ModalBody>
                <p>
                  Você tem certeza que deseja{" "}
                  <strong className="text-red-500">DELETAR</strong> esse
                  doador?
                </p>
              </ModalBody>
              <ModalFooter>
                <Button color="primary" variant="bordered" onPress={onClose}>
                  Cancelar
                </Button>
                <Button
                  color="danger"
                  onPress={onClose}
                  onClick={() => handlerDelete(Number(codigo))}
                >
                  Deletar
                </Button>
              </ModalFooter>
            </>
          )}
        </ModalContent>
      </Modal>
    </div>
  );
}