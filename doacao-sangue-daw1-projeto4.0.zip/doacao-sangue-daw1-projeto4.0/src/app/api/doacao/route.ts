import prisma from "@/lib/db"
import { DoacaoRequestPost } from "@/types/doador-request.interface"
import { RH, TipoSanguineo } from "@prisma/client"

export async function POST(req: Request) {
    const { id, volume, data, hora, tipoSanguineo, rh } = await req.json() as DoacaoRequestPost

    try {

        if (!(id && volume && tipoSanguineo && rh))
            throw new Error("Valores Invalidos!")

        await prisma.doacao.create({
            data: {
                volume: Number(volume),
                authorId: Number(id),
                data,
                hora,
                tipoSanguineo: TipoSanguineo[tipoSanguineo as keyof typeof TipoSanguineo],
                rh: RH[rh as keyof typeof RH]
            }
        })

        return new Response('Success!', {
            status: 200,
        })
    } catch (error: any) {
        console.log(error)
        return new Response(`Webhook error: ${error.message}`, {
            status: 400,
        })
    }
}